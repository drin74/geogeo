from pydantic import BaseModel, EmailStr, Field
from datetime import datetime
from typing import Optional

class RegisterIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    full_name: str = Field(default="", max_length=120)

class UserOut(BaseModel):
    id: int
    email: str
    full_name: str
    class Config:
        from_attributes = True

class FolderIn(BaseModel):
    name: str = Field(min_length=1, max_length=120, pattern=r"^[^/\\\\<>:\"|?*]+$")
    parent_id: Optional[int] = None

class FileOut(BaseModel):
    id: int
    name: str
    mime_type: str
    size: int
    is_folder: bool
    parent_id: Optional[int]
    is_trashed: bool
    created_at: datetime
    class Config:
        from_attributes = True
