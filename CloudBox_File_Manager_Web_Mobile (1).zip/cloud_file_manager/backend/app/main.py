import os, uuid, shutil
from pathlib import Path
from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Form, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from sqlalchemy import select
from .database import Base, engine, get_db
from .models import User, FileItem
from .schemas import RegisterIn, UserOut, FolderIn, FileOut
from .security import hash_password, verify_password, create_access_token, decode_token

Base.metadata.create_all(bind=engine)
app = FastAPI(title="CloudBox API", version="1.0.0", description="Shared Web + Mobile file manager API")
origins = os.getenv("CORS_ORIGINS", "*").split(",")
app.add_middleware(CORSMiddleware, allow_origins=origins if origins != ["*"] else ["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
oauth2 = OAuth2PasswordBearer(tokenUrl="/auth/login")
STORAGE = Path(os.getenv("STORAGE_DIR", "./storage"))
STORAGE.mkdir(parents=True, exist_ok=True)
MAX_UPLOAD = int(os.getenv("MAX_UPLOAD_MB", "100")) * 1024 * 1024

def current_user(token: str = Depends(oauth2), db: Session = Depends(get_db)):
    uid = decode_token(token)
    user = db.get(User, uid) if uid else None
    if not user:
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    return user

def owned_item(db: Session, item_id: int, user_id: int):
    item = db.scalar(select(FileItem).where(FileItem.id == item_id, FileItem.owner_id == user_id))
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    return item

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/auth/register", response_model=UserOut, status_code=201)
def register(payload: RegisterIn, db: Session = Depends(get_db)):
    email = payload.email.lower()
    if db.scalar(select(User).where(User.email == email)):
        raise HTTPException(status_code=409, detail="Email already registered")
    user = User(email=email, full_name=payload.full_name.strip(), hashed_password=hash_password(payload.password))
    db.add(user); db.commit(); db.refresh(user)
    return user

@app.post("/auth/login")
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == form.username.lower()))
    if not user or not verify_password(form.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Incorrect email or password")
    return {"access_token": create_access_token(user.id), "token_type": "bearer"}

@app.get("/auth/me", response_model=UserOut)
def me(user: User = Depends(current_user)):
    return user

@app.get("/files", response_model=list[FileOut])
def list_files(parent_id: int | None = None, q: str | None = None, trashed: bool = False, db: Session = Depends(get_db), user: User = Depends(current_user)):
    stmt = select(FileItem).where(FileItem.owner_id == user.id, FileItem.is_trashed == trashed, FileItem.parent_id == parent_id)
    if q:
        stmt = stmt.where(FileItem.name.ilike(f"%{q[:120]}%"))
    return list(db.scalars(stmt.order_by(FileItem.is_folder.desc(), FileItem.name.asc())).all())

@app.post("/folders", response_model=FileOut, status_code=201)
def create_folder(payload: FolderIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    if payload.parent_id is not None:
        parent = owned_item(db, payload.parent_id, user.id)
        if not parent.is_folder or parent.is_trashed:
            raise HTTPException(status_code=400, detail="Invalid parent folder")
    folder = FileItem(owner_id=user.id, parent_id=payload.parent_id, name=payload.name.strip(), storage_name=f"folder-{uuid.uuid4().hex}", mime_type="inode/directory", is_folder=True, size=0)
    db.add(folder); db.commit(); db.refresh(folder)
    return folder

@app.post("/files/upload", response_model=FileOut, status_code=201)
async def upload_file(file: UploadFile = File(...), parent_id: int | None = Form(None), db: Session = Depends(get_db), user: User = Depends(current_user)):
    name = Path(file.filename or "upload.bin").name[:255]
    if not name or name in {".", ".."}:
        raise HTTPException(status_code=400, detail="Invalid filename")
    if parent_id is not None:
        parent = owned_item(db, parent_id, user.id)
        if not parent.is_folder or parent.is_trashed:
            raise HTTPException(status_code=400, detail="Invalid parent folder")
    storage_name = uuid.uuid4().hex
    destination = STORAGE / storage_name
    total = 0
    try:
        with destination.open("wb") as out:
            while chunk := await file.read(1024 * 1024):
                total += len(chunk)
                if total > MAX_UPLOAD:
                    raise HTTPException(status_code=413, detail=f"Maximum upload size is {MAX_UPLOAD // (1024*1024)} MB")
                out.write(chunk)
    except Exception:
        destination.unlink(missing_ok=True)
        raise
    item = FileItem(owner_id=user.id, parent_id=parent_id, name=name, storage_name=storage_name, mime_type=file.content_type or "application/octet-stream", size=total)
    db.add(item); db.commit(); db.refresh(item)
    return item

@app.get("/files/{item_id}/download")
def download_file(item_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    item = owned_item(db, item_id, user.id)
    if item.is_folder or item.is_trashed:
        raise HTTPException(status_code=404, detail="File not available")
    path = STORAGE / item.storage_name
    if not path.is_file():
        raise HTTPException(status_code=404, detail="Stored file is missing")
    return FileResponse(path, filename=item.name, media_type=item.mime_type)

@app.delete("/files/{item_id}", status_code=204)
def trash_file(item_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    item = owned_item(db, item_id, user.id)
    item.is_trashed = True
    db.commit()

@app.post("/files/{item_id}/restore", response_model=FileOut)
def restore_file(item_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    item = owned_item(db, item_id, user.id)
    item.is_trashed = False
    db.commit(); db.refresh(item)
    return item

@app.delete("/files/{item_id}/permanent", status_code=204)
def permanently_delete(item_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    item = owned_item(db, item_id, user.id)
    if item.is_folder:
        children = list(db.scalars(select(FileItem).where(FileItem.owner_id == user.id, FileItem.parent_id == item.id)).all())
        if children:
            raise HTTPException(status_code=409, detail="Folder must be empty before permanent deletion")
    if not item.is_folder:
        (STORAGE / item.storage_name).unlink(missing_ok=True)
    db.delete(item); db.commit()

@app.get("/folders/{folder_id}/children", response_model=list[FileOut])
def folder_children(folder_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    folder = owned_item(db, folder_id, user.id)
    if not folder.is_folder:
        raise HTTPException(status_code=400, detail="Not a folder")
    return list(db.scalars(select(FileItem).where(FileItem.owner_id == user.id, FileItem.parent_id == folder_id, FileItem.is_trashed == False).order_by(FileItem.is_folder.desc(), FileItem.name)).all())
