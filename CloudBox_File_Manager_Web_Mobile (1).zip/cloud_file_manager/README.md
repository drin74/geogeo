# CloudBox — файловый менеджер Web + Native Mobile

Готовый стартовый проект облачного файлового менеджера с общей PostgreSQL БД для веб-клиента и мобильного приложения Android/iOS.

## Состав

- `backend/` — FastAPI REST API, JWT-аутентификация, PostgreSQL, загрузка/скачивание файлов.
- `web/` — адаптивный React-интерфейс в стиле современного облачного диска.
- `mobile/` — Expo / React Native приложение для Android и iOS.
- `docker-compose.yml` — запуск PostgreSQL, API и Web одной командой.
- Файлы хранятся в общем volume Docker, а метаданные и пользователи — в PostgreSQL.

> Это рабочий MVP для локального запуска и дальнейшего развития, а не сертифицированный production-сервис. Перед публичным размещением обязательно замените секреты, включите HTTPS, настройте резервные копии, лимиты и антивирусную проверку загружаемых файлов.

## Быстрый запуск (Docker)

Нужны Docker Desktop и Docker Compose.

```bash
docker compose up --build
```

Откройте:
- Web: http://localhost:5173
- API и Swagger: http://localhost:8000/docs
- Health: http://localhost:8000/health

Создайте аккаунт через форму регистрации в веб-интерфейсе. Войдите с теми же данными в мобильном приложении — файлы будут общими.

Остановка:

```bash
docker compose down
```

Удалить также БД и файлы (ОСТОРОЖНО, безвозвратно):

```bash
docker compose down -v
```

## Запуск мобильного приложения

1. Установите Node.js 20+.
2. Перейдите в каталог `mobile`.
3. Установите зависимости: `npm install`.
4. Скопируйте `.env.example` в `.env` и укажите адрес API.
5. Запустите: `npx expo start`.
6. Откройте проект в Expo Go или соберите native-приложение через EAS Build.

Пример адреса API:
- Android Emulator: `http://10.0.2.2:8000`
- iOS Simulator: `http://localhost:8000`
- Физический телефон: `http://АДРЕС_ВАШЕГО_КОМПЬЮТЕРА_В_LAN:8000`

В `mobile/.env`:
```env
EXPO_PUBLIC_API_URL=http://192.168.1.10:8000
```
Телефон и компьютер должны быть в одной Wi-Fi сети. Для реального устройства не используйте `localhost`.

## Локальный запуск Backend без Docker

Требуется Python 3.11+ и PostgreSQL.

```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

Установите переменные окружения `DATABASE_URL`, `JWT_SECRET`, `STORAGE_DIR`, затем:

```bash
uvicorn app.main:app --reload
```

Таблицы создаются автоматически при старте приложения.

## Возможности MVP

- Регистрация и вход по email/паролю.
- JWT access token.
- Личные файлы каждого пользователя.
- Загрузка нескольких файлов.
- Создание папок и навигация по папкам.
- Поиск по имени.
- Скачивание файлов.
- Корзина: мягкое удаление и восстановление через API (в UI есть перемещение в корзину).
- Ограничение размера загрузки на сервере.
- Защита от доступа к чужим файлам.
- Общая БД и файловое хранилище для Web и Mobile.

## API

Основные маршруты:
- `POST /auth/register` — регистрация.
- `POST /auth/login` — вход, OAuth2 form.
- `GET /auth/me` — текущий пользователь.
- `GET /files?parent_id=<id>&q=<query>&trashed=false` — список.
- `POST /folders` — создать папку.
- `POST /files/upload` — загрузить файл (multipart `file`, optional `parent_id`).
- `GET /files/{id}/download` — скачать.
- `DELETE /files/{id}` — переместить в корзину.
- `POST /files/{id}/restore` — восстановить.
- `GET /folders/{id}/children` — список содержимого папки.

## Структура

```text
cloud_file_manager/
├── backend/
├── web/
├── mobile/
├── docker-compose.yml
└── README.md
```

## Важные замечания по безопасности

- В Compose используются демонстрационные пароли. Замените их до публикации.
- Для production вынесите секреты в secret manager / `.env`, не коммитьте их.
- Настройте HTTPS reverse proxy, rate limiting, резервное копирование PostgreSQL и файлового volume.
- Для больших файлов добавьте resumable/chunked upload и объектное хранилище S3.
- Добавьте подтверждение email, восстановление пароля и аудит действий перед промышленным использованием.
